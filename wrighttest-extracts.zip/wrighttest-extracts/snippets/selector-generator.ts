/**
 * Selector Strategy:
 * Priority: Role + Name -> Text -> Scoped Locators.
 */

export function deriveSelectorCandidates(selector: string): string[] {
  const candidates: string[] = [];

  // Attempt to extract Rolle/Name from Playwright's getByRole
  const roleNameMatch = selector.match(/getByRole\(\s*'([^']+)'\s*,\s*\{\s*name:\s*'([^']+)'/);
  if (roleNameMatch) {
    const [_, role, name] = roleNameMatch;
    // Strategy 1: Exact Role Match
    candidates.push(`page.getByRole('${role}', { name: '${name}', exact: true })`);
    // Strategy 2: Text Fallback
    candidates.push(`page.getByText('${name}')`);
    // Strategy 3: Loose Locator
    if (role === 'button') candidates.push(`page.locator('button', { hasText: '${name}' })`);
  }

  // Strategy 4: Scoping (Anti-ambiguity)
  const scopes = ['main', 'nav', 'form', 'section'];
  const baseSelector = selector.replace(/^page\./, '');
  
  for (const scope of scopes) {
    candidates.push(`page.locator('${scope}').locator('${baseSelector}')`);
  }

  return [...new Set(candidates)];
}
