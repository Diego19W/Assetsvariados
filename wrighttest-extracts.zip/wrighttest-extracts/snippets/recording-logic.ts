import { spawn, type ChildProcess } from 'node:child_process';
import path from 'node:path';
import fsPromises from 'node:fs/promises';

/**
 * Capture logic pattern: 
 * WrightTest uses Playwright's built-in codegen feature as a sidecar process.
 * It redirects the output to a temporary file and then parses that file line-by-line.
 */

export async function startRecording(startUrl: string, outputFile: string): Promise<ChildProcess> {
  // Pattern: Spawning playwright codegen as a child process
  const proc = spawn(
    'npx',
    [
      'playwright',
      'codegen',
      '--browser',
      'chromium',
      '--output',
      outputFile,
      startUrl
    ],
    {
      stdio: 'pipe',
      detached: true
    }
  );

  return proc;
}

/**
 * Parsing logic:
 * Uses Regex to convert Playwright DSL lines back into internal Step objects.
 */
export function parseCodegenLine(trimmed: string) {
  // Example for click
  const clickMatch = trimmed.match(/^await\s+(.+?)\.click\(([\s\S]*?)\);?$/);
  if (clickMatch) {
    return {
      action: 'click',
      selector: clickMatch[1].replace(/\.$/, ''),
    };
  }

  // Example for fill
  const fillMatch = trimmed.match(/^await\s+(.+?)\.fill\(([\s\S]*?)\);?$/);
  if (fillMatch) {
    const value = fillMatch[2].match(/(['"`])([\s\S]*?)\1/)?.[2];
    return {
      action: 'fill',
      selector: fillMatch[1].replace(/\.$/, ''),
      value
    };
  }
  
  return null;
}
