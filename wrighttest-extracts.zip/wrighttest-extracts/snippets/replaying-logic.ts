import { type Page } from 'playwright';
import { expect } from '@playwright/test';

/**
 * Replay Pattern: 
 * Sequential execution of steps with high-level abstraction.
 * Includes selector recovery (trying alternative candidates if the primary fails).
 */

async function runStep(page: Page, step: any) {
  switch (step.action) {
    case 'goto':
      await page.goto(step.value, { waitUntil: 'domcontentloaded' });
      break;
      
    case 'click':
      // Pattern: Selector Recovery Loop
      const candidates = [step.selector, ...(step.selectorCandidates || [])];
      let success = false;
      
      for (const candidate of candidates) {
        try {
          const locator = page.locator(candidate);
          // Auto-wait and click
          await locator.click({ timeout: 5000 });
          success = true;
          break;
        } catch (e) {
          // Continue to next candidate
        }
      }
      
      if (!success) throw new Error(`Action failed for all candidates: ${candidates.join(', ')}`);
      break;

    case 'assertText':
      await expect(page.locator(step.selector)).toContainText(step.expected, { timeout: 10000 });
      break;
  }
}

/**
 * Execution Loop:
 * Handles tracing, screenshots, and error reporting.
 */
export async function executeWorkflow(page: Page, steps: any[]) {
  const results = [];
  for (const step of steps) {
    const start = Date.now();
    try {
      await runStep(page, step);
      results.push({ status: 'passed', duration: Date.now() - start });
    } catch (error) {
      results.push({ status: 'failed', error: error.message, duration: Date.now() - start });
      break; // Stop on first failure
    }
  }
  return results;
}
