# Análisis de WrightTest – Arquitectura de Grabación y Replay

Este documento analiza los mecanismos internos de WrightTest para la automatización de pruebas con Playwright, enfocándose en la captura de eventos, el motor de ejecución y la resiliencia de selectores.

## 1. Modelo de Datos del Workflow

WrightTest utiliza una estructura de datos plana para representar una serie de acciones de usuario. El núcleo es el objeto `Step`.

- **Workflow/Test**: Contiene metadatos (nombre, URL base, dispositivo) y un array de `steps`.
- **Step**: Define una acción única (ej. `click`, `fill`) junto con su objetivo (selector o valor esperado) y candidatos de respaldo.

> [!NOTE]
> El esquema completo se encuentra en [workflow-schema.json](./wrighttest-extracts/schemas/workflow-schema.json).

## 2. Patrón de Grabación (Recording)

La grabación en WrightTest no reinventa la rueda; utiliza `playwright codegen` de forma ingeniosa:

1. **Sidecar Process**: Lanza `npx playwright codegen` como un subproceso con `--output` apuntando a un archivo temporal.
2. **File Watching/Parsing**: Una vez detenida la sesión, lee el archivo `.ts` generado por Playwright.
3. **Regex Parsing**: Convierte las líneas del DSL de Playwright (ej. `await page.getByRole('button').click()`) en objetos JSON `Step` internos.

> [!TIP]
> Ver implementación simplificada en [recording-logic.ts](./wrighttest-extracts/snippets/recording-logic.ts).

## 3. Patrón de Replay (Execution Engine)

El motor de replay reside en un worker asíncrono que procesa una cola de trabajos (BullMQ).

- **Sequential Loop**: Itera sobre la lista de pasos interpolando variables de entorno.
- **Auto-Wait**: Delega el "waiting" nativo de Playwright, pero añade una capa de "Selector Recovery".
- **Resiliencia**: Si el selector principal falla, el motor itera sobre una lista de `selectorCandidates` (respaldos) antes de reportar un error.
- **Artifacts**: Captura capturas de pantalla después de cada paso y genera un Playwright Trace (`.zip`) completo de la sesión.

> [!TIP]
> Ver lógica del motor en [replaying-logic.ts](./wrighttest-extracts/snippets/replaying-logic.ts).

## 4. Selector Generator: Estrategias de Resiliencia

La generación de selectores robustos es vital para evitar "flaky tests". WrightTest emplea varias capas:

1. **Prioridad Semántica**: Prefiere `getByRole` con nombre exacto (Accesibilidad).
2. **Text Fallback**: Si el rol falla, intenta localizar por texto plano.
3. **Scoping**: Si hay ambigüedad (varios elementos iguales), intenta añadir un prefijo de contexto (ej. `nav > button` en lugar de solo `button`).
4. **Candidates Array**: Durante la grabación, se calculan múltiples variantes que se guardan en el paso para ser usadas como "healers" durante el replay.

> [!TIP]
> Ver estrategias en [selector-generator.ts](./wrighttest-extracts/snippets/selector-generator.ts).

## 5. Dependencias y Licencia

- **Core**: `playwright`, `bullmq`, `fastify`, `prisma`, `zod`.
- **Estatus de Licencia**: **"WrightTest Source-Available License v1.0"**.
  - **RESTRICCIÓN**: No permite el uso del código para crear un servicio SaaS competidor sin permiso.
  - **PERMITIDO**: Uso personal, educativo, investigación y uso interno organizacional.
  - **No es Open Source (MIT/Apache)**: Se debe tener precaución si se planea comercializar una solución basada directamente en este código.

## 6. Recomendaciones de Integración (Rust/Tauri)

- **Adaptación a Tauri**: 
  - El `Recorder` puede ser adaptado utilizando Playwright en modo "headed" o conectándose a una instancia de navegador existente. 
  - La lógica de parsing de `codegen` es fácilmente portable a Rust (usando regex), permitiendo generar el JSON de workflow desde la salida de Playwright.
- **Selector Engine**: 
  - El sistema de `selectorCandidates` es valioso. En una implementación Rust/Tauri se recomienda mantener este "pool" de candidatos para implementar **Self-Healing** (recuperación automática de selectores).
- **Desacoplamiento**:
  - Se recomienda extraer `selector-variants.ts` y la lógica de validación de `Step` en una librería pura (sin dependencias de DB/FS) para facilitar las pruebas unitarias y la portabilidad.

---
*Análisis generado por Antigravity el 18 de mayo de 2026.*
