/**
 * HyperAgent Configuration Example
 */

const config = {
  provider: "anthropic", // "openai" | "anthropic" | "gemini" | "deepseek"
  model: "claude-3-5-sonnet-20241022",
  apiKey: process.env.ANTHROPIC_API_KEY,
  temperature: 0,
  debug: true,
  cdpActions: true, // Use CDP-ready actions
};
