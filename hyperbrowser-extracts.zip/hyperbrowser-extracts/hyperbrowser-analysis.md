# HyperAgent Analysis - IA Contextual & Control Inteligente

## Visión General
HyperAgent es un sistema de automatización de navegación basado en IA que utiliza una arquitectura de bucle cerrado (Closed-Loop) de observación-decisión-acción. Su punto fuerte es la representación del DOM mediante un **Árbol de Accesibilidad (A11y Tree)**, lo que reduce drásticamente el ruido en comparación con el HTML crudo.

## 1. Flujo de Decisión de IA
1.  **Observación**: Captura el estado actual mediante CDP (Chrome DevTools Protocol) para generar un árbol de accesibilidad y una captura de pantalla (screenshot).
2.  **Contexto**: Une el objetivo final, el historial de acciones previas, las variables del usuario, el árbol A11y y la imagen en un prompt estructurado.
3.  **Inferencia**: Envía el prompt a un LLM (Anthropic, OpenAI, etc.) solicitando una respuesta JSON que contenga `thoughts`, `memory` y la siguiente `action`.
4.  **Ejecución**: Despacha la acción de forma asíncrona a través de Playwright o CDP.
5.  **Re-evaluación**: Invalida la caché del DOM tras acciones de escritura y vuelve al paso 1.

## 2. Patrones de Ingeniería de Prompts
-   **JSON Forzado**: Se utiliza `zod` para definir el esquema de salida y se inyecta en el prompt para obligar al modelo a seguir un formato estricto.
-   **One-Action-at-a-Time**: El sistema prohíbe explícitamente predecir múltiples pasos; el modelo debe concentrarse solo en la acción inmediata.
-   **Few-Shot**: Incluye ejemplos claros de acciones JSON para guiar al modelo (`examples-actions.ts`).
-   **Encapsulamiento de ID**: Los elementos se referencian mediante un `encodedId` (ej. "0-5125"), desacoplando al LLM de la complejidad de los Selectores CSS o XPaths crudos.

## 3. Manejo de Incertidumbre y Errores
-   **Acción `wait`**: Si el modelo no está seguro del estado (ej. página cargando), se le instruye a usar `wait` para reintar con un estado fresco.
-   **Retroalimentación de Esquema**: Si el LLM falla al generar un JSON válido, el sistema añade los errores de validación de `zod` al siguiente prompt para que el modelo "aprenda" de su error.
-   **Stuck Detection**: Existe un límite de fallos o esperas consecutivas (5 por defecto) antes de marcar la tarea como fallida.

## 4. Dependencias Clave
-   **LLM SDKs**: `@anthropic-ai/sdk`, `openai`, `@google/genai`.
-   **Browser**: `playwright-core`, `patchright`.
-   **Validación**: `zod` (fundamental para el control de flujo).
-   **Imagen**: `jimp` para procesamiento y composición de overlays visuales.

## 5. Recomendaciones para Rust/Tauri (`ai-engine`)
-   **Desacoplamiento**: La lógica de `dom-capture` (en TypeScript) puede ser portada a Rust usando `chromium-oxide` o `headless-chrome`, manteniendo la misma estructura de árbol A11y stringified.
-   **Bridge de LLM**: Implementar una interfaz similar a `HyperAgentLLM` en Rust para facilitar el cambio entre Ollama (local) y proveedores cloud.
-   **Adaptador de Observación**: Separar la generación de la cadena de texto del DOM de la decisión. HyperAgent usa un formato muy simple: `[encodedId] type: name attributes`.

## 6. Limitaciones Detectadas
-   **Licencia**: **AGPL-3.0**. Esto implica restricciones significativas para software comercial propietario; debe tenerse en cuenta si se planea una integración directa.
-   **Latencia**: El bucle depende enteramente de la velocidad del LLM y de la captura recursiva del árbol A11y por CDP.
-   **Costo**: El uso de capturas de pantalla base64 en cada paso eleva el consumo de tokens significativamente.

## 7. Interfaces de Desacoplamiento (Sugerencia)
-   `IAgent`: Define el bucle `step()`.
-   `IObserver`: Genera la representación textual y visual del estado.
-   `ICommandExecutor`: Traduce la salida JSON a llamadas de Playwright/CDP.
