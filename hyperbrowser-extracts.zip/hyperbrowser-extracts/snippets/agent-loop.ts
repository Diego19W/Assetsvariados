/**
 * HyperAgent Decision Loop
 * Source: src/agent/tools/agent.ts
 */

export const runAgentTask = async (ctx: AgentCtx, taskState: TaskState) => {
  while (true) {
    // 1. Observe (Capture DOM + Screenshot)
    const domState = await captureDOMState(page, { useCache: true });
    const screenshot = await compositeScreenshot(page, domState.visualOverlay);

    // 2. Build Messages (Context Assembly)
    const msgs = await buildAgentStepMessages(baseMsgs, taskState.steps, taskState.task, page, domState, screenshot);

    // 3. LLM Invoke (Decision)
    const response = await ctx.llm.invokeStructured({
      schema: AgentOutputFn(actionSchema),
      options: { temperature: 0 }
    }, msgs);

    const action = response.parsed.action;
    if (action.type === "complete") break;

    // 4. Action Execution
    const actionOutput = await runAction(action, domState, page, ctx);

    // 5. Update State
    taskState.steps.push({ agentOutput: response.parsed, actionOutput });
    currStep++;
  }
};
