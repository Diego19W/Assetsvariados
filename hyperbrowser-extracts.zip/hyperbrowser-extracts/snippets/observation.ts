/**
 * HyperAgent Observation Logic
 * Source: src/agent/messages/builder.ts
 */

export const buildAgentStepMessages = async (
  baseMessages: HyperAgentMessage[],
  steps: AgentStep[],
  task: string,
  page: Page,
  domState: A11yDOMState,
  screenshot: string | undefined
): Promise<HyperAgentMessage[]> => {
  const messages = [...baseMessages];
  
  messages.push({ role: "user", content: `=== Final Goal ===\n${task}\n` });
  messages.push({ role: "user", content: `=== Current URL ===\n${page.url()}\n` });

  // History mapping
  if (steps.length > 0) {
    messages.push({ role: "user", content: "=== Previous Actions ===\n" });
    for (const step of steps) {
      const { thoughts, memory, action } = step.agentOutput;
      messages.push({ role: "assistant", content: `Thoughts: ${thoughts}\nMemory: ${memory}\nAction: ${JSON.stringify(action)}` });
      messages.push({ role: "user", content: step.actionOutput.message });
    }
  }

  // DOM as string (Accessibility Tree)
  messages.push({ role: "user", content: `=== Elements ===\n${domState.domState}\n` });

  // Screenshot as Base64 Image
  if (screenshot) {
    messages.push({
      role: "user",
      content: [
        { type: "text", text: "=== Page Screenshot ===\n" },
        { type: "image", url: `data:image/png;base64,${screenshot}`, mimeType: "image/png" }
      ]
    });
  }

  return messages;
};
