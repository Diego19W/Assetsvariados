/**
 * HyperAgent Action Parsing & Validation
 * Source: src/types/agent/types.ts & src/agent/tools/agent.ts
 */
import { z } from "zod";

// --- Multi-modal Output Schema ---
export const AgentOutputFn = (actionsSchema: z.ZodUnion<any>) =>
  z.object({
    thoughts: z.string().describe("Your reasoning about the current state"),
    memory: z.string().describe("Summary of successful actions completed so far"),
    action: actionsSchema,
  });

// --- Dynamic Action Schema Generation ---
const getActionSchema = (actions: Array<AgentActionDefinition>) => {
  const zodDefs = actions.map((action) =>
    z.object({
      type: z.literal(action.type),
      params: action.actionParams,
    })
  );
  return z.union(zodDefs as any);
};

// --- LLM Invoke with Schema ---
const response = await ctx.llm.invokeStructured({
  schema: AgentOutputFn(actionSchema),
  options: { temperature: 0 }
}, messages);
