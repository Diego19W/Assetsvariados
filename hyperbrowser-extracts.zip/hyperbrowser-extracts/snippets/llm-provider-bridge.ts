/**
 * HyperAgent LLM Provider Abstraction
 * Source: src/llm/providers/
 */

export interface HyperAgentLLM {
  invokeStructured(params: { schema: z.ZodType<any>; actions?: any[]; options?: any }, messages: any[]): Promise<{ parsed: any; rawText: string }>;
  invoke(messages: any[], options?: any): Promise<{ text: string }>;
}

// Example: Anthropic implementation (simplified)
export class AnthropicClient implements HyperAgentLLM {
  async invokeStructured(params: any, messages: any) {
    const response = await this.client.messages.create({
      model: this.model,
      messages: convertToAnthropicMessages(messages),
      tools: convertToAnthropicTools(params.actions), // Optional tool usage
      // ...
    });
    // Parsing logic to handle both tool_calls and JSON blocks
  }
}
